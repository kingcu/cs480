//
//	internal type representations
//	written by Tim Budd
//

abstract class Type { 

	abstract public int size ( );
}
