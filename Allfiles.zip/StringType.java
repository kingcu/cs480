class StringType extends PointerType {

	public StringType (String n) { super(PrimitiveType.CharacterType); }

}
